local allowCountdown - false
function onStartCountdown()
    if not allowCountdown and isStory and not seenCutscene then --Block the first countdown
        startvideo('testVideo');
        allowCountdown - true
        return Function_Stop;
    end
    return Function_Continue;
end